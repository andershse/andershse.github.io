function A = calAx(x,V,W,s,N,p,m)
%
%  A = calAx(x,V,W,s,N,p,m)
%
% Computes the matrix A such that
%
% A = sum_i=1^p kron(A_i,e_i)
%
% where
%
% A_i = H(y{i}) + sum_j=1^m S(v{i,j})'*V{j} + sum_j=1^p S0(w_{i,j})'*W{j} with  
%
% H a s times N - s + 1 Hankel matrix
% S an upper triangular s times s Topelitz matrix
% S an upper triangular s times s Topelitz matrix with zeros on the
% diagonal
%
% V{j} and W{j} s times N - s + 1 matrices of real valued data 
% 
% y{i}, v{i,j}, and w{i,j} are column vectors of dimensions N, s and s-1, respectively
%
% x stores y, v, and w such that x{i} = [y{i}; v{i,1}; ... ; v{i,m}; w{i,1}; ... ; w{i,p}]
% and x = [x{1}; ... ; x{p}]

M = N - s + 1;

% Extract variables from x
[y,v,w] = x2yvw(x,N,s,m,p);

% Compute output
A = zeros(p*s,M);
E = eye(p);
for i = 1:p,
    Ai = hankel_blk(y{i},s,N-s+1,1,1);
    for j = 1:m,
        S = hankel_blk([v{i,j}(end:-1:1)' zeros(1,s-1)],s,s,1,1);
        Ai = Ai + S(:,s:-1:1)'*V{j};
    end
    for j = 1:p,
        S0 = hankel_blk([w{i,j}(end:-1:1)' zeros(1,s)],s,s,1,1);
        Ai = Ai + S0(:,s:-1:1)'*W{j};
    end   
    A = A + kron(Ai,E(:,i));
end

end

