function x = calAx_adj(Z,V,W,s,N,p,m)
%
% x = calAx_adj(Z,V,W,s,N,p,m)
% 
% computes the adjunct of 
%
% A(x) = sum_i=1^p kron(A_i,e_i)
%
% where
%
% A_i = H(y{i}) + sum_j=1^m S(v{i,j})'*V{j} + sum_j=1^p S0(w_{i,j})'*W{j} with  
%
% H a s times N - s + 1 Hankel matrix
% S an upper triangular s times s Topelitz matrix
% S an upper triangular s times s Topelitz matrix with zeros on the
% diagonal
%
% V{j} and W{j} s times N - s + 1 matrices of real valued data 
% 
% y{i}, v{i,j}, and w{i,j} are column vectors of dimensions N, s and s-1, respectively
%
% x stores y, v, and w such that x{i} = [y{i}; v{i,1}; ... ; v{i,m}; w{i,1}; ... ; w{i,p}]
% and x = [x{1}; ... ; x{p}]
%
% Z is a p*s times N - s + 1 matrix variable

M = N - s + 1;

% Extract ZZ{i} from Z
for i = 1:p,
    ZZ{i} = Z(i:p:p*s,:);
end

x = [];
for i = 1:p,
    x = [x; hankel_blk_adj(ZZ{i},s,N-s+1,1,1)];
    for j = 1:m,
        vv = hankel_blk_adj(V{j}*ZZ{i}(s:-1:1,:)',s,s,1,1);
        x = [x; vv(s:-1:1,:)];
    end
    for j = 1:p,
        ww = hankel_blk_adj(W{j}*ZZ{i}(s:-1:1,:)',s,s,1,1);
        x = [x; ww(s-1:-1:1,:)];
    end
end

end

