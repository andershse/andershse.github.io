function sys = estimate_ss_nuclear(T,S,Obs,m,p)
%
% sys = estimate_ss_nuclear(T,S,Obs,m,p)
%
% estimates a state space realization using Method 3 as described in
%
% Verhaegen, M. and A. Hansson: N2SID: Nuclear Norm Subspace Identification
%
% INPUT
% T        Topelitz matrix T_y,s
% S        Toeplitz matrix U_u,s
% Obs      extended observability matrix
% m        dimension of input
% p        dimension of output
%
% OUTPUT
% sys.A,B,C,D,K  state-space model
% sys.x1         initial state x(1)
% sys.n          model order
%
[rp,n] = size(Obs);
r = rp/p;

C = Obs(1:p,:);
Phi = Obs(1:end-p,:)\Obs(p+1:end,:);

CPhi = C;
for k = 1:r-2,
    CPhi = [C; CPhi*Phi];
end
CPhiK = T(p+1:end,1:p);
K = CPhi\CPhiK;

A = Phi + K*C;

% stabilize A
[Us,Ts] = schur(A,'complex');
dTs = diag(Ts);
idTs = find(abs(dTs) >= 1.0);
while ~isempty(idTs)
    %disp('Stabilize matrix A');
    dTs(idTs) = dTs(idTs).^-1;
    Ts(1:n+1:end) = dTs;
    A = real(Us*Ts*Us');

    [Us,Ts] = schur(A,'complex');
    dTs = diag(Ts);
    idTs = find(abs(dTs) >= 1.0);
end


CPhiGamma = S(p+1:end,1:m);
Gamma = CPhi\CPhiGamma;

D = S(1:p,1:m);
B = Gamma + K*D;

sys = idss(A,B,C,D,K);
end

