load CD_player_arm.dat
CD = detrend(CD_player_arm,'constant');
CD = CD(121:end,:);
Nide = 200;
CD = CD(1:Nide,:);
u = CD(:,1:2);
y = CD(:,3:4);
lambda = logspace(-1.5,3,20);
method = 1;
[sys,sv,fit,lambda_opt,KK] = n2sid(y,y,u,u,lambda,method);
subplot(121)
semilogx(lambda,KK(:,2),'o')
xlabel('lambda')
ylabel('VAF')
subplot(122)
semilogx(lambda,KK(:,1),'o')
xlabel('lambda')
ylabel('Order n')