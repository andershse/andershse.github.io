function [y,v,w] = x2yvw(x,N,s,m,p)
%
% [y,v,w] = x2yvw(x,N,s,m,p)
%
% extracts the structs y, v, and w from x
%

n = N + s*m + (s-1)*p;
for i = 1:p,
    xx{i} = x((i-1)*n+1:i*n);
    y{i} = xx{i}(1:N);
    vv{i} = xx{i}(N+1:N+s*m);
    ww{i} = xx{i}(N+s*m+1:end);
    for j = 1:m,
        v{i,j} = vv{i}((j-1)*s+1:j*s);
    end
    for j = 1:p,
        w{i,j} = ww{i}((j-1)*(s-1)+1:j*(s-1));
    end
end
end

