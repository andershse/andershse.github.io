function [sys,sv,fit,lambda_opt,KK] = n2sid(yid,yval,uid,uval,lambda,method)
%
% [sys,sv,fit,lambda_opt,KK] = n2sid(yid,yval,uid,uval,lambda,method)
%
% performs N2SID system identification as described in more detail in 
% Verhaegen, M. and A. Hansson: N2SID: Nuclear Norm Subspace Identification
% 
% INPUT
% yid      output data for identification
% yval     output data for optimizing lambda w.r.t. fit
% uid      input data for identification
% uval     input data for optimizing lambda w.r.t. fit
% lambda   vector of regularization paramters
% method   method can be 1, 2 or 3 as described in the above reference
%          and are different methods for computing a state-space
%          realization
%
% OUTPUT
% sys.A,B,C,D,K  state-space model 
% sys.x1         initial state x(1)
% sys.n          model order
% sv             singular values as in (15) in the above reference
% fit            optimal value of fit
% lambda_opt     optimal value of lambda
% KK             is a matrix with as many rows as there are elements in
%                lambda and two columns. Element (i,1) contains the 
%                state dimension corresponding to lambda(i) and 
%                element (i,2) contains the fit corresponding to lambda(i)

[~,sys,Ssvd,~] = optimize_yhat(yid,uid,method,lambda);

vdata = iddata(yval,uval,1);

memo = cell(length(lambda),2);
KK = zeros(length(lambda),2);
for jj = 1:length(lambda),
    nopt = size(sys{jj}.A,1);
    [~,FITvopt,~] = compare(vdata,sys{jj},Inf);
    KK(jj,:) = [nopt,mean(FITvopt)];
    memo{jj,1}=sys{jj};
    memo{jj,2}=Ssvd{jj};
end

[~,I] = max(KK,[],1);
sys = memo{I(2),1};
fit = KK(I(2),2);
sv = memo{I(2),2};
lambda_opt = lambda(I(2));

end

