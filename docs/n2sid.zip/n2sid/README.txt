N2SID: a MATLAB package for system identification based on nuclear norm
system identification

Copyright (c) 2014 Anders Hansson and Michel Verhaegen.

The approach of identifying a system is based on nuclear norm 
optimization of a subspace system identification formulation.
The optimization is solved using the alternating direction method of
multipliers (ADMM). Details of the algorithm are described in the paper
"N2SID: Nuclear Norm Subspace Identification" by M. Verhaegen and
A. Hansson.

The software package contains a main function 

* n2sid

that performs the system identification. To use it you have to also 
install the package SIMIO that can be downloaded from 

http://www.zhang-liu.com/software/simio.html

WARNING: In this package there are three matlab functions with names in conflict with the names of functions in the N2SID package, namely compute_M.p, compute_Q.m and estimate_ss.m. Because of this caution has to be taken to make sure that the correct functions are used. 

License.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License for more details.

A copy of the GPL license can be found in the file gpl.txt.