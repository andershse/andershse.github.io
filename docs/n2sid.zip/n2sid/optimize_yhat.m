function [yhat,sys,Svd,stat] = optimize_yhat(y,u,method,lambda,opt)
%
% [yhat,sys,Svd,stat] = optimize_yhat(y,u,lambda,opt)
%
% computes an optimized output yhat and a state space model sys
% from to the N2SID optimization problem
% 
%     minimize |Yhat - Tu*U - Ty*Y|_* + lambda * |y-yhat|_F^2.
%
% as described in more detail in 
% Verhaegen, M. and A. Hansson: N2SID: Nuclear Norm Subspace Identification
% 
%
% INPUT
% y         N x p real matrix for the measured outputs, p is the number
%           of outputs, N is the number of data points
% u         N x m real matrix for the inputs, m is the number of inputs
% lambda    regularization parameter, se below for more details
% method    method can be 1, 2 or 3 as described in the above reference
%           and are different methods for computing a state-space
%           realization
% opt       optional structure array for specifying parameters of the 
%           alternating direction methods of multiplier (ADMM) algorithm
%    
% OUTPUT
% yhat      optimized output y
% sys       state-space model with the following fields
%           -- 'A', 'B', 'C', 'D', 'K' the state-space matrices
%              'K' is not computed by all methods
%           -- 'x1', the initial state x(1) (if computed by the method)
%           -- 'n', the model order
% Svd       Singular values as in (15) in the above reference
% stat      structure array with statistics of the ADMM algorithm
%
% The regularization parameter lambda can be entered as a vector.  If it 
% is a vector with L elements, L problem instances of 
%     minimize |Yhat - Tu*U - Ty*Y|_* + lambda(ii) * |y-yhat|_F^2.
% are solved.  The results are stored in struct yhat{ii},sys{ii},stat{ii}.
% If L > 6, simultaneous diagonalization of C and M is computed.
 
% Dimensions of input and output data
[N,m] = size(u);
p = size(y,2);
if size(y,1) ~= N
    error('Input u and output y must have the same number of data points');
end

% r: block row dimension in Hankel matrices Yhat, U and U
r = 15;

% Dimensions of block Hankel matrices
% Yhat, Y: rp x M; U: rm x M
M = N+1-r;

% Form Hankel matrices from input-output-data
for j = 1:m,
    U{j} = -hankel_blk(u(:,j),r,M,1,1);
end
for j = 1:p,
    Y{j} = -hankel_blk(y(:,j),r,M,1,1);
end
    
% Define the optimization data Ao, Aoa, MM, Bo, Co, x0 for rnna_admm.m
Aop  = @(x) calAx(x,U,Y,r,N,p,m);
Aopa = @(Z) calAx_adj(Z,U,Y,r,N,p,m);
[MM,M_time] = compute_M(r,N,m,p,U,Y); 
Bo = zeros(p*r,N-r+1);
x0 = [];
Co = [];
for i = 1:p,
    x0 = [x0; y(:,i); zeros(r*m+(r-1)*p,1)];
    Co = sparse([Co; ones(N,1); zeros(r*m+(r-1)*p,1)])*2;
end
x0 = sparse(x0);
Co = diag(Co);
if length(lambda) > 6
    [opt.Q,opt.d,Q_time] = compute_Q(Co,MM);
end

for ii = 1:length(lambda)
    opt.w = lambda(ii);
    
    % Solve the regularized nuclear norm optimization
    [x, stat1] = rnna_admm(Aop, Aopa, MM, Bo, Co, x0, opt);
    % Extract optimized variables
    [yhat1,s,t] = x2yvw(x,N,r,m,p);
    
    % Compute singular values
    Xt = calAx(x,U,Y,r,N,p,m);
    [Usvd,Ssvd,Vsvd] = svd(Xt,'econ');      
    Ssvd1 = diag(Ssvd);
    
    % Determine model order
    logsv = log(Ssvd1(1:r));
    nn = min(10,find(logsv>(max(logsv)+min(logsv))/2,1,'last'));
    
    % Estimate state-space model
    St = zeros(p*r,m*r); 
    Tt = zeros(p*r,p*r);
    idm = eye(m); idp = eye(p);
    for i = 1:p,
        for j = 1:m,
            temp = hankel_blk([s{i,j}(end:-1:1)' zeros(1,r-1)],r,r,1,1);
            St = St + kron(temp(:,end:-1:1)',idp(:,i)*idm(j,:));
        end
        for j = 1:p,
            temp = hankel_blk([t{i,j}(end:-1:1)' zeros(1,r)],r,r,1,1);
            Tt = Tt + kron(temp(:,end:-1:1)',idp(:,i)*idp(j,:));
        end
    end
    
    if method == 1,
        syss = estimate_ss(Tt,Usvd(:,1:nn),y',u');
    elseif method == 2, 
        syss = estimate_ss_states(Vsvd(:,1:nn),u,y); 
    elseif method == 3, 
        syss = estimate_ss_nuclear(Tt,St,Usvd(:,1:nn),m,p); 
    else
        'wrong number for method'
    end

    yyhat = [];
    for i = 1:p,
        yyhat = [yyhat yhat1{i}];
    end
    
    % store solutions
    if length(lambda) == 1,
        yhat = yyhat;
        stat = stat1;
        sys = syss;
        Svd = Ssvd1;
    else
        yhat{ii} = yyhat;
        stat{ii} = stat1;
        sys{ii} = syss;
        Svd{ii} = Ssvd1;
    end
end
