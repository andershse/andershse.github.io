function sys = estimate_ss_states(Xt,u,y)
%
% sys = estimate_ss_states(Xt,u,y)
%
% estimates a state space realization using Method 2 as described in
%
% Verhaegen, M. and A. Hansson: N2SID: Nuclear Norm Subspace Identification
%
% INPUT
% Xt       The right singular vectors as in (15)
% y        output
% u        input 
%
% OUTPUT
% sys.A,B,C,D,K  state-space model
% sys.x1         initial state x(1)
% sys.n          model order
%
m = size(u,2);
p = size(y,2);
N = size(Xt,1);
n = size(Xt,2);

M1 = [Xt(1:N-1,:)';
    u(1:N-1,:)';
    y(1:N-1,:)'];
M1e = Xt(2:N,:)'*pinv(M1);
Arond = M1e(:,1:n);
Brond = M1e(:,n+1:n+1+(m-1));
K = M1e(:,n+1+m:end);
M2 = [Xt(1:N,:)';
    u(1:N,:)'];
M2e = y(1:N,:)'*pinv(M2);
C = M2e(:,1:n);
D = M2e(:,n+1:end);
A = Arond + K*C;
B = Brond + K*D;

% stabilize A
[Us,Ts] = schur(A,'complex');
dTs = diag(Ts);
idTs = find(abs(dTs) >= 1.0);
while ~isempty(idTs)
    %disp('Stabilize matrix A');
    dTs(idTs) = dTs(idTs).^-1;
    Ts(1:n+1:end) = dTs;
    A = real(Us*Ts*Us');

    [Us,Ts] = schur(A,'complex');
    dTs = diag(Ts);
    idTs = find(abs(dTs) >= 1.0);
end
sys = idss(A,B,C,D,K);



