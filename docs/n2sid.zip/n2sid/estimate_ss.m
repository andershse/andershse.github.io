function sys = estimate_ss(T,Obs,y,u)
%
% sys = estimate_ss(T,Obs,y,u)
%
% estimates a state space realization using Method 1 as described in
%
% Verhaegen, M. and A. Hansson: N2SID: Nuclear Norm Subspace Identification
% 
% INPUT
% T        Topelitz matrix T_y,s
% Obs      extended observability matrix
% y        output
% u        input 
%
% OUTPUT
% sys.A,B,C,D  state-space model
% sys.x1       initial state x(1)
% sys.n        model order

[p,N] = size(y);
m = size(u,1);

[rp,n] = size(Obs);
r = rp/p;

C = Obs(1:p,:);
Phi = Obs(1:end-p,:)\Obs(p+1:end,:);

CPhi = C;
for k = 1:r-2,
    CPhi = [C; CPhi*Phi];
end
CPhiK = T(p+1:end,1:p);
K = CPhi\CPhiK;

A = Phi + K*C;

% stabilize A
[Us,Ts] = schur(A,'complex');
dTs = diag(Ts);
idTs = find(abs(dTs) >= 1.0);
while ~isempty(idTs)
    %disp('Stabilize matrix A');
    dTs(idTs) = dTs(idTs).^-1;
    Ts(1:n+1:end) = dTs;
    A = real(Us*Ts*Us');

    [Us,Ts] = schur(A,'complex');
    dTs = diag(Ts);
    idTs = find(abs(dTs) >= 1.0);
end


F1 = zeros(p*N,n);
F1(1:p,:) = C;
for kk = 1:N-1
    F1(kk*p+1:(kk+1)*p,:) = F1((kk-1)*p+1:kk*p,:)*A;
end
F2 = kron(u',eye(p));
F3 = zeros(p*N,n*m);
for kk = 1:N-1
    F3(kk*p+1:end,:) = F3(kk*p+1:end,:) + kron(u(:,1:N-kk)',F1((kk-1)*p+1:kk*p,:));
end
F = [F1,F2,F3];
x = F\y(:);
xerr = norm(F*x-y(:),'fro')/norm(y,'fro');
x1 = x(1:n);
D = reshape(x(n+1:n+p*m),p,m);
B = reshape(x(n+p*m+1:n+p*m+n*m),n,m);

% store solutions
sys = idss(A,B,C,D);

