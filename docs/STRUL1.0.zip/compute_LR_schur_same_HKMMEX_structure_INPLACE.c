#include <math.h>
#include "mex.h"
#include "matrix.h"

void mexFunction( int nlhs, mxArray *plhs[], int nrhs, const mxArray*prhs[])

/* schurmat = compute_schur_GHKM(n,KiUKjt,KjVKit,nK) */
{
        
    unsigned int i = 0;
    unsigned int j = 0;
    unsigned int k = 0;
    unsigned int l = 0;
    unsigned int index1 = 0;
    unsigned int index2 = 0;
    const unsigned int n1  = (int) (mxGetScalar(prhs[0]));
    const unsigned int n2  = (int) (mxGetScalar(prhs[1]));
    const unsigned int Nx = (int) (mxGetScalar(prhs[2]));
    const double * Rit_U_Lj = mxGetPr(prhs[3]);
    const double * Rjt_V_Li = mxGetPr(prhs[4]);
    const double * Rit_U_Rj = mxGetPr(prhs[5]);
    const double * Ljt_V_Li = mxGetPr(prhs[6]);
    const double * Lit_U_Lj = mxGetPr(prhs[7]);
    const double * Rjt_V_Ri = mxGetPr(prhs[8]);
    const double * Lit_U_Rj = mxGetPr(prhs[9]);
    const double * Ljt_V_Ri = mxGetPr(prhs[10]);
    double temp;    
   
    unsigned int deltahi = 0;
    unsigned int deltalj = 0;
    unsigned int epsilhi = 0;
    unsigned int epsillj = 0;
    const unsigned int * epsilon = (int*) mxGetData(prhs[11]);
    const unsigned int * delta = (int*) mxGetData(prhs[12]);
    const unsigned int * num_pos = (int*) mxGetData(prhs[13]);
    
    const unsigned int * schurindex = (int*) mxGetData(prhs[14]);
    const unsigned int NxGlobal = (int) (mxGetScalar(prhs[15])); 
    double  *schurmat; 
    schurmat = mxGetPr(prhs[16]); 
        
    for (i = 0; i < Nx; i++) 
    {
        for (j = i; j < Nx; j++)
        {
           temp = 0;
            for (k = 0; k < num_pos[i]; k++)                
            {                
                deltahi = delta[index1+k];
                epsilhi = epsilon[index1+k];
                for (l = 0; l < num_pos[j]; l++)
                {
                    deltalj = delta[index2+l];
           
                    epsillj = epsilon[index2+l];                    
                    
                             
                    temp += Rit_U_Lj[deltahi+epsillj*n2]*
                                        Rjt_V_Li[deltalj+epsilhi*n2]+
                                        Rit_U_Rj[deltahi+deltalj*n2]*
                                        Ljt_V_Li[epsillj+epsilhi*n1]+
                                        Lit_U_Lj[epsilhi+epsillj*n1]*
                                        Rjt_V_Ri[deltalj+deltahi*n2]+
                                        Lit_U_Rj[epsilhi+deltalj*n1]*
                                        Ljt_V_Ri[epsillj+deltahi*n1];                                                           
                    
                }

            }                                   
            index2 += num_pos[j];
            
            schurmat[(schurindex[i]-1)*NxGlobal+schurindex[j]-1] += temp;
            if (i<j)
            {
            schurmat[(schurindex[j]-1)*NxGlobal+schurindex[i]-1] += temp;
            }                         
        }
        index1 += num_pos[i];
        index2  = index1;
    } 
 
    return;
}

