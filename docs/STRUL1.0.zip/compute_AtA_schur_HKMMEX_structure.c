#include <math.h>
#include "mex.h"
#include "matrix.h"

void mexFunction( int nlhs, mxArray *plhs[], int nrhs, const mxArray*prhs[])

/* schurmat = compute_schur_GHKM(n,KiUKjt,KjVKit,nK) */
{
        
    unsigned int i = 0;
    unsigned int j = 0;
    unsigned int k = 0;
    unsigned int l = 0;
    unsigned int index1 = 0;
    unsigned int index2 = 0;
    const unsigned int n  = (int) (mxGetScalar(prhs[0]));  
    const unsigned int Nx = (int) (mxGetScalar(prhs[1]));
    const double * Ai_U_Ait = mxGetPr(prhs[2]);
    const double * Ai_V_Ait = mxGetPr(prhs[3]);
    const unsigned int * epsilon = (int*) mxGetData(prhs[4]);
    const unsigned int * delta = (int*) mxGetData(prhs[5]);      
    const unsigned int * num_pos = (int*) mxGetData(prhs[6]);
    
    double  *schurmat;
    unsigned int deltahi = 0;
    unsigned int deltalj = 0;
    unsigned int epsilhi = 0;
    unsigned int epsillj = 0;
              

    plhs[0] = mxCreateDoubleMatrix(Nx, Nx, mxREAL); /*mxReal is our data-type */    
    schurmat = mxGetPr(plhs[0]); /* link the schurmat to the output */
       
    for (i = 0; i < Nx; i++) 
    {
        for (j = i; j < Nx; j++)
        {

            for (k = 0; k < num_pos[i]; k++)                
            {                
                deltahi = delta[index1+k];
                epsilhi = epsilon[index1+k];
                for (l = 0; l < num_pos[j]; l++)
                {
                    deltalj = delta[index2+l];
                    epsillj = epsilon[index2+l];                    

                    schurmat[i+j*Nx] += Ai_U_Ait[deltahi+epsillj*n]*
                                        Ai_V_Ait[deltalj+epsilhi*n];
                }

            }
            
            index2 += num_pos[j];
            schurmat[i*Nx+j]= schurmat[j*Nx+i];
        }
        index1 += num_pos[i];
        index2  = index1;
    } 
 
    return;
}
