#include <math.h>
#include "mex.h"
#include "matrix.h"

void mexFunction( int nlhs, mxArray *plhs[], int nrhs, const mxArray*prhs[])

/* schurmat = compute_schur_GHKM(n,KiUKjt,KjVKit,nK) */
{
        
    unsigned int i = 0;
    unsigned int j = 0;
    unsigned int k = 0;
    unsigned int l = 0;
    unsigned int index1 = 0;
    unsigned int index2 = 0;
    const unsigned int ni1  = (int) (mxGetScalar(prhs[0]));
    const unsigned int ni2  = (int) (mxGetScalar(prhs[1]));
    const unsigned int nj1  = (int) (mxGetScalar(prhs[2]));
    const unsigned int nj2  = (int) (mxGetScalar(prhs[3]));
    const unsigned int Nxi = (int) (mxGetScalar(prhs[4]));
    const unsigned int Nxj = (int) (mxGetScalar(prhs[5]));
    const double * Rit_U_Lj = mxGetPr(prhs[6]);
    const double * Rjt_V_Li = mxGetPr(prhs[7]);
    const double * Rit_U_Rj = mxGetPr(prhs[8]);
    const double * Ljt_V_Li = mxGetPr(prhs[9]);
    const double * Lit_U_Lj = mxGetPr(prhs[10]);
    const double * Rjt_V_Ri = mxGetPr(prhs[11]);
    const double * Lit_U_Rj = mxGetPr(prhs[12]);
    const double * Ljt_V_Ri = mxGetPr(prhs[13]);
    
    double  *schurmat;
    unsigned int deltahi = 0;
    unsigned int deltalj = 0;
    unsigned int epsilhi = 0;
    unsigned int epsillj = 0;
    const unsigned int * epsiloni = (int*) mxGetData(prhs[14]);
    const unsigned int * deltai = (int*) mxGetData(prhs[15]);
    const unsigned int * num_posi = (int*) mxGetData(prhs[16]);
    const unsigned int * epsilonj = (int*) mxGetData(prhs[17]);
    const unsigned int * deltaj = (int*) mxGetData(prhs[18]);
    const unsigned int * num_posj = (int*) mxGetData(prhs[19]);
              

    plhs[0] = mxCreateDoubleMatrix(Nxi, Nxj, mxREAL); /*mxReal is our data-type */    
    schurmat = mxGetPr(plhs[0]); /* link the schurmat to the output */

    for (i = 0; i < Nxi; i++)
    {
        for (j = 0; j < Nxj; j++)
        {
            for (k = 0; k < num_posi[i]; k++)                
            {                
                deltahi = deltai[index1+k];
                epsilhi = epsiloni[index1+k];

                for (l = 0; l < num_posj[j]; l++)
                {
                    deltalj = deltaj[index2+l];
                    epsillj = epsilonj[index2+l];
                    
                    
                    schurmat[i+j*Nxi] += Rit_U_Lj[deltahi+epsillj*ni2]*
                                         Rjt_V_Li[deltalj+epsilhi*nj2]+
                                         Rit_U_Rj[deltahi+deltalj*ni2]*
                                         Ljt_V_Li[epsillj+epsilhi*nj1]+
                                         Lit_U_Lj[epsilhi+epsillj*ni1]*
                                         Rjt_V_Ri[deltalj+deltahi*nj2]+
                                         Lit_U_Rj[epsilhi+deltalj*ni1]*
                                         Ljt_V_Ri[epsillj+deltahi*nj1];
                    
                }            

            }
            
            index2 += num_posj[j];
        }
        index1 += num_posi[i];
        index2 = 0;
    } 
 
    return;
    
    
    
/*    
    for (i = 0; i < ni; i++) 
    {
        for (j = i; j < ni; j++) 
        {

            for (k = 0; k < nj; k++)
            {
                for (l = k; l < nj; l++) 
                {


                    if (i == j && k == l)
                    {      
                        schurmat[index2*Nxi+index1] = KiUKjt[nKi*k+ni+i]*       KjVKit[nKj*j+l+nj]+
                                                      KiUKjt[nKi*k+nKj*ni+i+ni]*KjVKit[nKj*j+l]+
                                                      KiUKjt[nKi*k+i]*          KjVKit[nKj*j+nKj*ni+l+nj]+
                                                      KiUKjt[nKi*k+nKj*ni+i]*   KjVKit[nKj*j+nKj*ni+l];                       
                    }
                    else if (i == j)
                    {
                        schurmat[index2*Nxi+index1] = KiUKjt[nKi*k+ni+i]*       KjVKit[nKj*j+l+nj]+
                                                      KiUKjt[nKi*l+ni+i]*       KjVKit[nKj*j+k+nj]+
                                                      KiUKjt[nKi*k+nKj*ni+i+ni]*KjVKit[nKj*j+l]+
                                                      KiUKjt[nKi*l+nKj*ni+i+ni]*KjVKit[nKj*j+k]+
                                                      KiUKjt[nKi*k+i]*          KjVKit[nKj*j+nKj*ni+l+nj]+
                                                      KiUKjt[nKi*l+i]*          KjVKit[nKj*j+nKj*ni+k+nj]+
                                                      KiUKjt[nKi*k+nKj*ni+i]*   KjVKit[nKj*j+nKj*ni+l]+
                                                      KiUKjt[nKi*l+nKj*ni+i]*   KjVKit[nKj*j+nKj*ni+k];


                    }  
                    else if (k == l)
                    {
                        schurmat[index2*Nxi+index1] = KiUKjt[nKi*k+ni+i]*       KjVKit[nKj*j+l+nj]+
                                                      KiUKjt[nKi*k+ni+j]*       KjVKit[nKj*i+l+nj]+
                                                      KiUKjt[nKi*k+nKj*ni+i+ni]*KjVKit[nKj*j+l]+
                                                      KiUKjt[nKi*k+nKj*ni+j+ni]*KjVKit[nKj*i+l]+
                                                      KiUKjt[nKi*k+i]*          KjVKit[nKj*j+nKj*ni+l+nj]+
                                                      KiUKjt[nKi*k+j]*          KjVKit[nKj*i+nKj*ni+l+nj]+
                                                      KiUKjt[nKi*k+nKj*ni+i]*   KjVKit[nKj*j+nKj*ni+l]+
                                                      KiUKjt[nKi*k+nKj*ni+j]*   KjVKit[nKj*i+nKj*ni+l];                       


                    }
                    else
                    {
                        schurmat[index2*Nxi+index1] = KiUKjt[nKi*k+ni+i]*       KjVKit[nKj*j+l+nj]+
                                                      KiUKjt[nKi*l+ni+i]*       KjVKit[nKj*j+k+nj]+
                                                      KiUKjt[nKi*k+ni+j]*       KjVKit[nKj*i+l+nj]+
                                                      KiUKjt[nKi*l+ni+j]*       KjVKit[nKj*i+k+nj]+
                                                      KiUKjt[nKi*k+nKj*ni+i+ni]*KjVKit[nKj*j+l]+
                                                      KiUKjt[nKi*l+nKj*ni+i+ni]*KjVKit[nKj*j+k]+
                                                      KiUKjt[nKi*k+nKj*ni+j+ni]*KjVKit[nKj*i+l]+
                                                      KiUKjt[nKi*l+nKj*ni+j+ni]*KjVKit[nKj*i+k]+
                                                      KiUKjt[nKi*k+i]*          KjVKit[nKj*j+nKj*ni+l+nj]+
                                                      KiUKjt[nKi*l+i]*          KjVKit[nKj*j+nKj*ni+k+nj]+
                                                      KiUKjt[nKi*k+j]*          KjVKit[nKj*i+nKj*ni+l+nj]+
                                                      KiUKjt[nKi*l+j]*          KjVKit[nKj*i+nKj*ni+k+nj]+
                                                      KiUKjt[nKi*k+nKj*ni+i]*   KjVKit[nKj*j+nKj*ni+l]+
                                                      KiUKjt[nKi*l+nKj*ni+i]*   KjVKit[nKj*j+nKj*ni+k]+
                                                      KiUKjt[nKi*k+nKj*ni+j]*   KjVKit[nKj*i+nKj*ni+l]+
                                                      KiUKjt[nKi*l+nKj*ni+j]*   KjVKit[nKj*i+nKj*ni+k];

                    }
                    index2++;
                }
            }
            index1++;            
            index2 = 0;
        }        
    }
    
 */

}
