#include <math.h>
#include "mex.h"
#include "matrix.h"

void mexFunction( int nlhs, mxArray *plhs[], int nrhs, const mxArray*prhs[])

/* schurmat = compute_schur_HKM(n,p,Nx,L,V(1:n,1:n),U_ABt(1:n,:), ...
 * AB_U_ABt, V_ABt(1:n,:), AB_V_ABt,a,b) */
{
        
    unsigned int i = 0;
    unsigned int j = 0;
    unsigned int k = 0;
    unsigned int l = 0;
    
    unsigned int deltahi = 0;
    unsigned int epsilhi = 0;
    unsigned int deltalj = 0;
    unsigned int epsillj = 0;
 

    
    
    unsigned int index1 = 0;
    unsigned int index2 = 0;

        unsigned int ix1 = 0;
        unsigned int ix2 = 0;

        
    const unsigned int n1  = (int) (mxGetScalar(prhs[0]));  
    const unsigned int n2  = (int) (mxGetScalar(prhs[1]));
    const unsigned int Nx = (int) (mxGetScalar(prhs[2]));
    const double * Rit_U_Ri = mxGetPr(prhs[3]);
    const double * Rit_V_Ri = mxGetPr(prhs[4]);
    const double * Rit_U_Li = mxGetPr(prhs[5]);
    const double * Lit_U_Li = mxGetPr(prhs[6]);
    const double * Rit_V_Li = mxGetPr(prhs[7]);
    const double * Lit_V_Li = mxGetPr(prhs[8]);  
    const unsigned int * epsilon = (int*) mxGetData(prhs[9]);
    const unsigned int * delta = (int*) mxGetData(prhs[10]);      
    const unsigned int * num_pos = (int*) mxGetData(prhs[11]);
    const unsigned int * schurindex = (int*) mxGetData(prhs[12]);
    const unsigned int NxGlobal = (int) (mxGetScalar(prhs[13]));
    double  *schurmat;
    double temp;
       
    schurmat = mxGetPr(prhs[14]); 
    
    for (i = 0; i < Nx; i++) 
    {
        ix1 = (schurindex[i]-1)*NxGlobal;
        for (j = i; j < Nx; j++)
        {
            temp =  0;
            for (k = 0; k < num_pos[i]; k++)                
            {                
                deltahi = delta[index1+k];
                epsilhi = epsilon[index1+k];
                                                               
                for (l = 0; l < num_pos[j]; l++)
                {
                    deltalj = delta[index2+l];
                    epsillj = epsilon[index2+l];                    
                    temp += Rit_U_Li[deltahi+epsillj*n2]*Rit_V_Li[deltalj+epsilhi*n2]+
                                        Rit_U_Ri[deltahi+deltalj*n2]*Lit_V_Li[epsilhi+epsillj*n1]+
                                        Lit_U_Li[epsilhi+epsillj*n1]*Rit_V_Ri[deltahi+deltalj*n2]+
                                        Rit_U_Li[deltalj+epsilhi*n2]*Rit_V_Li[deltahi+epsillj*n2];                    
                } 
                            

            }
            
            schurmat[ix1+schurindex[j]-1] += temp;
            if (i<j)
            {
            schurmat[(schurindex[j]-1)*NxGlobal+schurindex[i]-1] += temp;
            }
                     
            index2 += num_pos[j];            
        }
        index1 += num_pos[i];
        index2  = index1;
    }
   
    return;
}

