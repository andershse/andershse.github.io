% This files automatically compiles the c-files needed in order to use the STRUL toolbox.
% Automatically generated Thu Apr 29 14:08:13 CEST 2010  

tic;
disp('mex compute_AtA_LR_schur_different_HKMMEX_structure.c');
mex -O compute_AtA_LR_schur_different_HKMMEX_structure.c;
disp('mex compute_AtA_schur_different_HKMMEX_structure.c');
mex -O compute_AtA_schur_different_HKMMEX_structure.c;
disp('mex compute_AtA_schur_HKMMEX_structure.c');
mex -O compute_AtA_schur_HKMMEX_structure.c;
disp('mex compute_AtA_schur_HKMMEX_structure_INPLACE.c');
mex -O compute_AtA_schur_HKMMEX_structure_INPLACE.c;
disp('mex compute_AtA_schur_same_HKMMEX_structure.c');
mex -O compute_AtA_schur_same_HKMMEX_structure.c;
disp('mex compute_AtA_x_schur_HKMMEX_structure.c');
mex -O compute_AtA_x_schur_HKMMEX_structure.c;
disp('mex compute_LR_AtA_schur_different_HKMMEX_structure.c');
mex -O compute_LR_AtA_schur_different_HKMMEX_structure.c;
disp('mex compute_LR_AtA_schur_same_HKMMEX_structure.c');
mex -O compute_LR_AtA_schur_same_HKMMEX_structure.c;
disp('mex compute_LR_schur_different_HKMMEX_structure.c');
mex -O compute_LR_schur_different_HKMMEX_structure.c;
disp('mex compute_LR_schur_HKMMEX_structure.c');
mex -O compute_LR_schur_HKMMEX_structure.c;
disp('mex compute_LR_schur_HKMMEX_structure_INPLACE.c');
mex -O compute_LR_schur_HKMMEX_structure_INPLACE.c;
disp('mex compute_LR_schur_same_HKMMEX_structure.c');
mex -O compute_LR_schur_same_HKMMEX_structure.c;
disp('mex compute_LR_schur_same_HKMMEX_structure_INPLACE.c');
mex -O compute_LR_schur_same_HKMMEX_structure_INPLACE.c;


disp('mex compute_LR_x_schur_HKMMEX_structure.c');
mex -O compute_LR_x_schur_HKMMEX_structure.c;
t = toc;

fprintf('Done! %i files compiled in %f seconds.\n',11,t);

