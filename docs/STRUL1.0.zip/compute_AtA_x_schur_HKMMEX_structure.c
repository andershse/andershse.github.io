#include <math.h>
#include "mex.h"
#include "matrix.h"

void mexFunction( int nlhs, mxArray *plhs[], int nrhs, const mxArray*prhs[])

/* schurmat = compute_schur_GHKM(n,KiUKit,KiVKit,nK) */
{
    
    const unsigned int n  = (int) (mxGetScalar(prhs[0]));
    const unsigned int Nx = (int) (mxGetScalar(prhs[1]));
    const double * AUMkVAt = mxGetPr(prhs[2]);
    const int * epsilon = (int*) mxGetData(prhs[3]);
    const int * delta = (int*) mxGetData(prhs[4]);      
    const int * num_pos = (int*) mxGetData(prhs[5]);
    
    unsigned int index1 = 0;
    unsigned int i = 0;
    unsigned int j = 0;
    double  *schurmatxp;
    plhs[0] = mxCreateDoubleMatrix(Nx, 1, mxREAL); /*mxReal is our data-type */
    schurmatxp = mxGetPr(plhs[0]); /* link the schurmat to the output */
    
    for (i = 0; i < Nx; i++)
    {    
        for (j = 0; j < num_pos[i]; j++)
        {
            schurmatxp[i] += AUMkVAt[delta[index1+j]*n  +epsilon[index1+j]];
            /*AUMkVAt[epsilon[index1+j]*n+delta[index1+j]];*/
        }
        
        index1 += num_pos[i];
    }
        
    return;
}
    
