#include <math.h>
#include "mex.h"
#include "matrix.h"

void mexFunction( int nlhs, mxArray *plhs[], int nrhs, const mxArray*prhs[])

/* schurmat = compute_schur_GHKM(n,KiUKit,KiVKit,nK) */
{
    
    const unsigned int n1  = (int) (mxGetScalar(prhs[0]));
    const unsigned int n2  = (int) (mxGetScalar(prhs[1]));
    const unsigned int Nx = (int) (mxGetScalar(prhs[2]));
    const double * RitUMVLi = mxGetPr(prhs[3]);
    const double * LitUMVRi = mxGetPr(prhs[4]);
        
    const int * epsilon = (int*) mxGetData(prhs[5]);
    const int * delta = (int*) mxGetData(prhs[6]);      
    const int * num_pos = (int*) mxGetData(prhs[7]);
    
    unsigned int index1 = 0;
    unsigned int i = 0;
    unsigned int j = 0;
    double  *schurmatxp;
    plhs[0] = mxCreateDoubleMatrix(Nx, 1, mxREAL); /*mxReal is our data-type */
    schurmatxp = mxGetPr(plhs[0]); /* link the schurmat to the output */
    
    for (i = 0; i < Nx; i++)
    {    
        for (j = 0; j < num_pos[i]; j++)
        {
            schurmatxp[i] += RitUMVLi[epsilon[index1+j]*n2+delta[index1+j]]+
                             LitUMVRi[delta[index1+j]*n1  +epsilon[index1+j]];
        }
        
        index1 += num_pos[i];
    }
        
    return;
}
    
