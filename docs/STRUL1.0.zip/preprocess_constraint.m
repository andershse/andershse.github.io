function [L,R,A,M,negated,negated_disc,epsilon,delta,numpos,xindicies,Pindicies] = preprocess_constraint(F)

%%
[l,m,r] = factors(F);
[constants,general,singles,pairs] = classifyfactors(l,m,r);
[constants,general,singles,pairs] = compressfactors2(constants,general,singles,pairs);

%%
usedp = zeros(size(pairs));
useds = zeros(size(singles));

L = {};
R = {};
A = {};
xindicies = getvariables(general);
Pindicies = {};
numpos = {};
epsilon = {};
delta = {};
negated = {};
negated_disc = {};

list_to_sort = [];

for k = 1:length(usedp)
    if ~usedp(k)
        L{end+1}{1} = pairs{k}.L;
        R{end+1}{1} = pairs{k}.R';
        negated{end+1}(1) = 0;
%         Mtmp{end+1} = pairs{k}.M;

        % If it is skew!
        if size(pairs{k}.M,1) == size(pairs{k}.M,2);            
            if isequal(pairs{k}.M+pairs{k}.M',zeros(size(pairs{k}.M)))
                L{end}{2} = -pairs{k}.R';
                R{end}{2} = pairs{k}.L;
                negated{end}(2) = 0;
            end
        end
        
        
        % Previous version fails if a matrix variable enters, but not all
        % individual elements appear
       % usedVariables = getvariables(pairs{k}.M);
        usedVariables = getvariables(pairs{k}.L*pairs{k}.M*pairs{k}.R);
        % No, that didn't work either. We must create a basis with respect
        % to the variables that appear in some factor
        usedVariables = intersect(getvariables(pairs{k}.M),getvariables(F));       
        list_to_sort(end+1) = usedVariables(1);
        
        
        A{end+1} = [];
        negated_disc{end+1} = [];
        usedp(k) = 1;
        
        % Dimension of the large matrix variable
        [n1 n2] = size(pairs{k}.M);
        tmp = getbase(pairs{k}.M);
        % The base matrix for the individual variables
        tmp = tmp(:,2:end);
        % but only these are actually used
        tmp = tmp(:,find(ismember(getvariables(pairs{k}.M),usedVariables)));

        tmp = tmp==1;
        % Number of positions that each scalar variable enters in
        numpos{end+1} = full(sum(tmp))';
        % Number of variables in this matrix
        Nx = length(numpos{end});
        
        % Place all base matrices in a 3D matrix
        a = reshape(full(tmp),n1,n2,Nx);
        
        [epsilon{end+1} delta{end+1} dummy] = ind2sub([n1,n2,Nx],find(a));
        Pindicies{end+1} = usedVariables;
        
        for i = k+1:length(usedp)
           if ~usedp(i) && isequal(pairs{k}.M,pairs{i}.M)              
               L{end}{end+1} = pairs{i}.L;
               R{end}{end+1} = pairs{i}.R';
               negated{end}(end+1) = 0;
               % Is it a skew variable?
               if size(pairs{k}.M,1) == size(pairs{k}.M,2);
                   if isequal(pairs{k}.M+pairs{k}.M',zeros(size(pairs{k}.M)))
                       L{end}{end+1} = -pairs{i}.R';
                       R{end}{end+1} = pairs{i}.L;
                       negated{end}(end+1) = 0;
                   end
               end
               usedp(i) = 1;

               % In case we have a variable that is transposed
           elseif ~usedp(i) && isequal(pairs{k}.M,pairs{i}.M')               
               L{end}{end+1} = pairs{i}.R';
               R{end}{end+1} = pairs{i}.L;
               
               temp = struct(pairs{k}.M);
               if strcmp(temp.originalbasis,'skew')
                   negated{end}(end+1) = 0;
               else
                   negated{end}(end+1) = 0;
               end
               
               usedp(i) = 1;

           end
           
        end
        if issymmetric(pairs{k}.M)
            for i = find(useds == 0)
                if isequal(pairs{k}.M,singles{i}.M)
                    A{end}{end+1} = singles{i}.R;
                    negated_disc{end}(end+1) = singles{i}.negated;
                    useds(i) = 1;
                end
            end
        end
    end
end

for k = 1:length(useds)
    if ~useds(k)
        L{end+1} = [];
        R{end+1} = [];
        A{end+1}{1} = singles{k}.R;
%         Mtmp{end+1} = singles{k}.M;
        
       
        
        negated{end+1} = [];
        % Old
        % list_to_sort(end+1) = getvariables(singles{k}.M(1));
        
        usedVariables = intersect(getvariables(singles{k}.M),getvariables(F));
        list_to_sort(end+1) = usedVariables(1);
        Pindicies{end+1} = usedVariables;
                
        useds(k) = 1;
        negated_disc{end+1} = singles{k}.negated;
        [n2 n1] = size(singles{k}.M);
        tmp = getbase(singles{k}.M);
        tmp = tmp(:,2:end);
        tmp = tmp(:,find(ismember(getvariables(singles{k}.M),usedVariables)));

        numpos{end+1} = full(sum(tmp))';
        Nx = length(numpos{end});
        
        a = reshape(full(tmp),n1,n2,Nx);
        [epsilon{end+1} delta{end+1} dummy] = ind2sub([n1,n2,Nx],find(a));


        for i = k+1:length(useds)
            if isequal(singles{k}.M,singles{i}.M)
                A{end}{end+1} = singles{i}.R;
                negated_disc{end}(end+1) = singles{i}.negated;
                useds(i) = 1;
            end
        end
    end    
end


%%

tmp = getbase(general);
tmp = full(tmp(:,2:end));
n = size(tmp,1);
tmp = reshape(tmp,sqrt(n),sqrt(n),size(tmp,2));

M = cell(1,size(tmp,3));
for k = 1:size(tmp,3)
    M{k} = tmp(:,:,k);
end

for k = 1:length(epsilon)
    epsilon{k} = uint32(epsilon{k}-1);  
    delta{k} = uint32(delta{k}-1);
    numpos{k} = uint32(numpos{k});
end

%%
% if length(R) < length(list_to_sort)
%     R{length(list_to_sort)} = [];
%     L{length(list_to_sort)} = [];
%     negated{length(list_to_sort)} = [];
% end
%%

for k = 1:length(list_to_sort)
    index = find(list_to_sort(k) == sort(list_to_sort));
    R_tmp{index} = R{k};
    L_tmp{index} = L{k};
    A_tmp{index} = A{k};
    epsilon_tmp{index} = epsilon{k};
    delta_tmp{index} = delta{k};
    numpos_tmp{index} = numpos{k};
    negated_tmp{index} = negated{k};
    negated_disc_tmp{index} = negated_disc{k};
end


if ~isempty(list_to_sort)
    R = R_tmp;
    L = L_tmp;
    A = A_tmp;
    epsilon = epsilon_tmp;
    delta = delta_tmp;
    numpos = numpos_tmp;
    negated = negated_tmp;
    negated_disc = negated_disc_tmp;
else
    R = [];
    L = [];
    A = [];
    epsilon = [];
    delta = [];
    numpos = [];
    negated = [];
    negated_disc = [];    
end






