clear all
n = 40;
A = randn(n);A = A - max(real(eig(A)))*eye(n)*1.5;
B = randn(n,1);
C = randn(1,n);

t = sdpvar(1);
P = sdpvar(n);
Constraints = [A'*P + P*A+C'*C P*B;B'*P -t] < 0;
Objective = t;

sol1 = solvesdp(Constraints,Objective,sdpsettings('solver','sdpt3'));
sol2 = solvesdp(Constraints,Objective,sdpsettings('solver','strul'));

sol1.solvertime/sol2.solvertime