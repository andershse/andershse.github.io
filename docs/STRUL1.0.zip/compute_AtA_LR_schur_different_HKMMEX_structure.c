#include <math.h>
#include "mex.h"
#include "matrix.h"

void mexFunction( int nlhs, mxArray *plhs[], int nrhs, const mxArray*prhs[])

/* schurmat = compute_schur_GHKM(n,KiUKjt,KjVKit,nK) */
{
        
    unsigned int i = 0;
    unsigned int j = 0;
    unsigned int k = 0;
    unsigned int l = 0;
    unsigned int index1 = 0;
    unsigned int index2 = 0;
    const unsigned int n   = (int) (mxGetScalar(prhs[0]));
    const unsigned int Nxi = (int) (mxGetScalar(prhs[1]));
    const unsigned int Nxj = (int) (mxGetScalar(prhs[2]));
    const double * A_U_R = mxGetPr(prhs[3]);
    const double * A_V_L = mxGetPr(prhs[4]);
    const double * A_V_R = mxGetPr(prhs[5]);
    const double * A_U_L = mxGetPr(prhs[6]);
    
    double  *schurmat;
    unsigned int deltahi = 0;
    unsigned int deltalj = 0;
    unsigned int epsilhi = 0;
    unsigned int epsillj = 0;
    const unsigned int * epsiloni = (int*) mxGetData(prhs[7]);
    const unsigned int * deltai = (int*) mxGetData(prhs[8]);
    const unsigned int * num_posi = (int*) mxGetData(prhs[9]);
    const unsigned int * epsilonj = (int*) mxGetData(prhs[10]);
    const unsigned int * deltaj = (int*) mxGetData(prhs[11]);
    const unsigned int * num_posj = (int*) mxGetData(prhs[12]);
              

    plhs[0] = mxCreateDoubleMatrix(Nxi, Nxj, mxREAL); /*mxReal is our data-type */    
    schurmat = mxGetPr(plhs[0]); /* link the schurmat to the output */

    for (i = 0; i < Nxi; i++)
    {
        for (j = 0; j < Nxj; j++)
        {
            for (k = 0; k < num_posi[i]; k++)                
            {                
                deltahi = deltai[index1+k];
                epsilhi = epsiloni[index1+k];

                for (l = 0; l < num_posj[j]; l++)
                {
                    deltalj = deltaj[index2+l];
                    epsillj = epsilonj[index2+l];

                    schurmat[i+j*Nxi] += A_U_L[deltahi+epsillj*n]*
                                         A_V_R[epsilhi+deltalj*n]+
                                         A_U_R[deltahi+deltalj*n]*
                                         A_V_L[epsilhi+epsillj*n];

                    
                }
            }
            index2 += num_posj[j];
        }
        index1 += num_posi[i];
        index2 = 0;
    } 
    return;
}
